---------------------------------------------------------------------------------------------------------------
READ THIS FIRST!
---------------------------------------------------------------------------------------------------------------
CFW ONLY; CEX ONLY; CCAPI ONLY; BLUS30838 ONLY; 1.24 UPDATE ONLY
---------------------------------------------------------------------------------------------------------------

1) MAKE SURE YOUR PS3 IS POWERED ON 

2) MAKE SURE YOUR PS3 IS CONNECTED TO THE SAME NETWORK AS YOUR COMPUTER

3) MAKE SURE YOU HAVE CCAPI INSTALLED ON BOTH YOUR PS3 AND YOUR COMPUTER

   --CCAPI v2.80_r9 on V4.88 EVILNAT CFW CEX AND WINDOWS 10
   
   --THIS RTM USES PS3LIB v4.4.0.0 IN LOCAL DIRECTORY
   
   --THIS RTM USES CCAPI v2.6.0.0 IN CCAPI INSTALL DIRECTORY
   
   --CCAPI-install.cmd WILL INSTALL THE PROPER CCAPI.DLL FOR THIS TOOL TO WORK

4) MAKE SURE MW3 IS RUNNING THE LATEST 1.24 UPDATE.

5) MAKE SURE MW3 GAME IS ALREADY RUNNING--HAVE THE GAME LOADED--BE IN GAME OR AT A MAIN MENU

6) CLICK CONNECT + ATTACH

7) ENJOY!

----------------------------------------------------------------------------------------------------------------
RTM OPTIONS
----------------------------------------------------------------------------------------------------------------

CONNECT + ATTACH---OPENS MENU TO SELECT DETECTED CONSOLE ON THE NETWORK
----------------------------------------------------------------------------------------------------------------

stayboogyUP---ALL PERKS, MAX PRIMARY AMMO, MAX SECONDARY AMMO, INFINITE GRENADES, INFINITE FLASHBANGS, 100K+ CLAYMORES, 100K+ C4

    --USE THIS IN SOLO SURVIVAL ONLY, WHILE IN GAME, CLICK THE BUTTON FOR THE GOODIES

    --IF YOU DON'T START WITH GRENADES OR FLASHBANGS, YOU HAVE TO BUY THEM THEN REACTIVATE THIS CHEAT TO SEE THE EFFECTS
    --IF YOU DON'T START WITH A SECONDARY WEAPON, YOU HAVE TO BUY ONE OR PICK ONE UP THEN REACTIVATE THIS CHEAT TO SEE THE EFFECTS
    --IF YOU DON'T SEE THAT YOU HAVE UNLIMITED AMOUNTS OF AMMO FOR EVERYTHING, MAKE SURE YOU HAVE AT LEAST ONE OF WHATEVER YOU NEED MAX OF AND REACTIVATE THIS CHEAT
    --IF YOU BUY A WEAPON, PICK UP A WEAPON, BUY AMMO, BUY ATTACHMENTS, BUY C4, BUY CLAYMORES, YOU MUST REACTIVATE THIS CHEAT FOR THAT *THING TO HAVE THE EFFECTS
    
    --CHEATS STAY ACTIVE UNLESS YOU CHANGE YOUR CONFIG SOMEHOW LIKE NORMAL--WHICH IS COMPLETELY UNNEEDED IF YOU USE THIS TOOL CORRECTLY
    --NEVER HAVE TO BUY AMMO OR A WEAPON, NEVER HAVE TO RESUPPLY ANY GEAR, ONLY SENTRIES, BODY ARMOR, RPGS IF YOU USE THEM, AND AIR SUPPORT HAVE TO BE BOUGHT.
    --THESE ARE THE ONLY VERIFIED AND WORKING SOLO SURVIVAL HACKS THAT WORK NOT ON PSN, WHETHER HOST OR NOT, WITH AN RTM
------------------------------------------------------------------------------------------------------------------

GodMode---DOES NOT ACTUALLY WORK LIKE MOST PEOPLE INTEND

    --ONLY INCLUDED FOR TESTING PURPOSES AND FOR THOSE WHO DESPERATELY NEED IT OR WANT IT, EVEN IF IT'S NOT REAL GODMODE OR EVEN CLOSE TO IT
-------------------------------------------------------------------------------------------------------------------

DISCONNECT--DISCONNECT FROM CONSOLE
-------------------------------------------------------------------------------------------------------------------

SOFT REBOOT--SOFT REBOOTS THE PS3
    
     --SOFT REBOOT YOUR PS3 SHOULD YOU GET FROZEN OR NEED TO FOR ANY OTHER REASON
     
-------------------------------------------------------------------------------------------------------------------
      
 